function [BOLD_TR,FC_cor,FC_sim,metastable_sim,synchrony_sim]=simulations_noise(f,Tmax,TR,dt,noise,n,main_add)
%% setup directory for lib, data, save
main_dir = fullfile([main_add,'\step2_simulation']); 
data_dir = fullfile(main_dir,'data'); 
save_dir = fullfile(main_dir,'result'); 

%% load model parameter
load(fullfile(data_dir,'Estimated_Parameter_K.mat'),'P'); 

%%  prepare the empirical data y  ->
% Define the strenght of all existing connections between the N nodes
% as a NxN matrix 
load(fullfile(data_dir,'FCSC_Desikan68.mat'),'FC_emp','SC','D'); 

N=size(SC,1); 
SC=SC/mean(SC(ones(N)-eye(N)>0));

D=D/1000;
% FC
FC = FC_emp;

%-----------------------------------------------------------
tmax=Tmax*60;

FC_mask = tril(ones(size(FC,1),size(FC,1)),0);
y = FC(~FC_mask); %use the elements above the maiin diagnal, y becomes a vector {samples x 1} 

a=[];%������FC_cor������
%% begin simulation
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   FC_sim=corr(BOLD_TR');
   y_sim=FC_sim(~FC_mask);
   FC_cor= corr(atanh(y_sim),atanh(y));
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(1)=FC_cor;
   save( [save_dir ,'/1_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
  
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin); 
   FC_sim=corr(BOLD_TR');
   y_sim=FC_sim(~FC_mask);
   FC_cor= corr(atanh(y_sim),atanh(y));
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(2)=FC_cor;
   save( [save_dir ,'/2_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
   
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin); 
   FC_sim=corr(BOLD_TR');
   y_sim=FC_sim(~FC_mask);
   FC_cor= corr(atanh(y_sim),atanh(y));
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(3)=FC_cor;
   save( [save_dir ,'/3_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
  
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);  
   FC_sim=corr(BOLD_TR');
   y_sim=FC_sim(~FC_mask);
   FC_cor= corr(atanh(y_sim),atanh(y));
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(4)=FC_cor;
   save( [save_dir ,'/4_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
   
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   FC_sim=corr(BOLD_TR');
   y_sim=FC_sim(~FC_mask);
   FC_cor= corr(atanh(y_sim),atanh(y));
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(5)=FC_cor;
   save( [save_dir ,'/5_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
 
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(6)=FC_cor;
   save( [save_dir ,'/6_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
  
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(7)=FC_cor;
   save( [save_dir ,'/7_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR); 
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(8)=FC_cor;
   save( [save_dir ,'/8_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);   
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(9)=FC_cor;
   save( [save_dir ,'/9_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
   
   [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1,1),P(1,2),tmax,dt,noise);
   [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
   bin=TR/dt_save;
   [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);    
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(10)=FC_cor;
   save( [save_dir ,'/10_k_simulationk.mat'] ,'BOLD_TR','neuro_act','metastable_sim','synchrony_sim','FC_cor','FC_sim');
      
   [b,c]=sort(a,'descend');
   
   for i=1:1:n
       file2 = fullfile(save_dir,num2str(c(i)));
       ad=fullfile([file2,'_k_simulationk.mat']);
       load(ad,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
       save( [main_add,'\result\Assistant_Simulation\',num2str(i),'_timeserious_k.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
   end
end
