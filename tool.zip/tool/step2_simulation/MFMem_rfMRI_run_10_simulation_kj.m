function [BOLD_TR,FC_cor]=MFMem_rfMRI_run_10_simulation_kj(Tmax,TR,dt,n,main_add)
%% setup directory for lib, data, save

main_dir = fullfile([main_add,'\step2_simulation']); 
data_dir = fullfile(main_dir,'data'); 
save_dir = fullfile(main_dir,'result'); 

%% load model parameter
parameter_file_name = 'Estimated_Parameter_RWW.mat';
load ([data_dir '\' parameter_file_name],'Para_E');

%%  prepare the empirical data y  ->
% Define the strenght of all existing connections between the N nodes
% as a NxN matrix 
 FCSC_file_name = 'FCSC_Desikan68_rww.mat';
 load([data_dir '\' FCSC_file_name]);

FC = FC_emp;
 
 %scaling the SC
 SC = SC./max(max(SC)).*0.2;

%-----------------------------------------------------------
a=[];%������FC_cor������
%% begin simulation
   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(1)=FC_cor;
   save( [save_dir ,'\1_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');
  
   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(2)=FC_cor;
   save( [save_dir ,'\2_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(3)=FC_cor;
   save( [save_dir ,'\3_rww_simulationrww.mat'],'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(4)=FC_cor;
   save( [save_dir ,'\4_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');
   
   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(5)=FC_cor;
   save( [save_dir ,'\5_rww_simulationrww.mat'],'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(6)=FC_cor;
   save( [save_dir ,'\6_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(7)=FC_cor;
   save( [save_dir ,'\7_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(8)=FC_cor;
   save( [save_dir ,'\8_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(9)=FC_cor;
   save( [save_dir ,'\9_rww_simulationrww.mat'],'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TR/dt); %down sample 
   [FC_sim,FC_cor] = estimation_corr_emp_sim(FC,BOLD_TR);  
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   a(10)=FC_cor;
   save( [save_dir ,'\10_rww_simulationrww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_cor','FC_sim');

   [b,c]=sort(a,'descend');
   
   for i=1:1:n
       file2 = fullfile(save_dir,num2str(c(i)));
       ad=fullfile([file2,'_rww_simulationrww.mat']);
       load(ad,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
       save( [main_add,'\result\Assistant_Simulation\',num2str(i),'_timeserious_rww.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
   end
   
end
