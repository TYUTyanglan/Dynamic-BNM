function [FC_sim,FC_cor] = estimation_corr_emp_sim(FC_emp,BOLD_sim)

FC_mask = tril(ones(size(FC_emp,1),size(FC_emp,1)),0);
y = FC_emp(~FC_mask); %use the elements above the maiin diagnal, y becomes a vector {samples x 1} 
FC_sim=corr(BOLD_sim');
y_sim=FC_sim(~FC_mask);
FC_cor= corr(atanh(y_sim),atanh(y)); %correlation between 2 FCs
end
