function CC_check = GA_fitness_noise(P,SC,D,f,y_FC,FC_mask,y_out,tmax,TR,dt,noise)

EstimationStep=10;

for v=1:1:EstimationStep 
  [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,P(1),P(2),tmax,dt,noise);
  [BOLD_X] = CompareNeuroimaging(Phases_Save,dt_save);
  bin=TR/dt_save;
  [BOLD_Y] = rfMRI_simBOLD_downsampling(BOLD_X,bin);
  FC_sim = corr(BOLD_Y');
  y_out=y_out+FC_sim(~FC_mask);
end
  y_out_ave=y_out/EstimationStep;
  FC_cor= corr(atanh(y_out_ave),atanh(y_FC));
  disp(FC_cor)

 CC_check=0.4-FC_cor;
end