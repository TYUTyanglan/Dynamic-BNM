function [FC_simR, CC_check] =  Kuramoto_rfMRI_nsolver_eul_sto_noise(parameter,prior,SC,D,y_FC,FC_mask,Tepochlong,TR,ifRepara,dt,f,noise)

%-----------------------------------------------------------------------------
% FC_simR, CC_check] = CBIG_mfm_rfMRI_nsolver_eul_sto(parameter,prior,SC,y_FC,FC_mask,Nstate,Tepochlong,TBOLD,ifRepara)
%
% Function to 
%  (a)solve diffitial equation of dynamic mean field and hemodynamic model using stochastic Euler method 
%  (b)caculate simulated functional connectivity (FC) from simulated BOLD
%  (c)caculate correlation between emprical FC and simulated FC 
%
% Input:
%     - SC:        structural connectivity matrix
%     - y_FC:      functional connectivity vector (after mask)
%     - FC_mask:   used to select uppertragular elements
%     - Nstate:    noise randon seed
%     - Tepochlong:simulation long in [min], exclusive 2min pre-simulation(casted)
%     - TBOLD:     BOLD-signal time resolution
%     - ifRepara:  re-parameter turn on=1/off=0
%
% Output:
%     - FC_simR:  simulated FC, only entries above main diagonal, in vector form
%     - RSN_FC_simR
%     - CC_check: cross correlation of 2 FCs 
%
% Reference:
%     [1](Deco 2013), Resting-state functional connectivity emerges from structurally and dynamically shaped slow linear fluctuations.
%     [2](Friston 2000), Nonlinear responses in fMRI: the Balloon model, Volterra kernels, and other hemodynamics.
%----------------------------------------------------------------------------

%caculate first [BOLD,yT,fT,qT,vT,zT,Time], then caculate FC_stim


%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
%(a) solve diffitial equation of dynamic mean field and hemodynamic model using stochastic Euler method 
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

if size(parameter, 2) > 1
    error('Input argument ''parameter'' should be a column vector');
end

if ifRepara == 1
    parameter = exp(parameter).*prior;
end


%-----------------------------------------------------------------------
%initial system
%-----------------------------------------------------------------------
%simulation time

%% main body: caculation 

% tmax=Tepochlong*TR;
tmax=Tepochlong*60;
 [Phases_Save,dt_save]= Kuramoto_rfMRI_ode1_noise(parameter,SC,D,tmax,f,dt,noise);

X=sin(Phases_Save); 
[N, w] = size(X);

%% Compare with static BOLD FC (NEEDS LONG SIMULATION TIMES)

% First transform simulations into BOLD signal using the Balloon-Windkessel
% model
% Transform into BOLD signal
% w_cut=w; % ɾ��ǰ10��ʱ���?BOLD_X=zeros(N,w);
for n=1:N
    T=w*dt_save;
    r=X(n,:);
    b = BOLDs(T,dt_save,r);
    BOLD_X(n,:)=b;  
end

BOLD_d = rfMRI_simBOLD_downsampling(BOLD_X,TR/dt_save); %down sample 

FC_sim = corr(BOLD_d');
FC_simR = FC_sim(~FC_mask);


CC_check = corr(atanh(FC_simR),atanh(y_FC));


end

