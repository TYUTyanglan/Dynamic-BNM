function [BOLD_X] = CompareNeuroimaging(Phases_Save,dt_save)
%%%%%%%%%%
%
% Code to compare simulation results with neuroimaging data:
% fMRI: the BOLD signal correlation matrix (static FC)
%
%%%%%%%%%

X=sin(Phases_Save); 
[N, w] = size(X);

%% Compare with static BOLD FC (NEEDS LONG SIMULATION TIMES)

% First transform simulations into BOLD signal using the Balloon-Windkessel
% model
% Transform into BOLD signal
% w_cut=w; % ɾ��ǰ10��ʱ���
w_cut=w-(20/dt_save)+2; 
BOLD_X=zeros(N,w_cut);
% BOLD_X=zeros(N,w);
for n=1:N
    T=w*dt_save;
    dt=dt_save;
    r=X(n,:);
    b = BOLDs(T,dt,r);
    BOLD_X(n,:)=b;  
end
