function [Para_E,rrr_z_max]=GS_rww(Metastable,metastable,ksdist,FCr_z,main_add)
[m,l]=size(Metastable);
Gs=zeros(m,l);
Met=zeros(m,l);
KSDist=zeros(m,l);
for i=1:m
    for j=1:l
        Met(i,j)=1-abs(metastable-Metastable(i,j));
        KSDist(i,j)=(1-ksdist(i,j))^2;
        Gs(i,j)=Met(i,j)*FCr_z(i,j)*KSDist(i,j);
    end
end
len=length(Gs(:));
Gss=reshape(Gs,1,len);
[b,c]=sort(Gss,'descend');
for i=1:1:len
    [x,y]=find(Gs==b(i));
    if((FCr_z(x,y)>0.34)&&(KSDist(x,y)<0.4))
        G=1+0.2*(x-1);
        noise=0.0005+0.0001*(y-1);
        Para_E=[G noise];
        rrr_z_max=FCr_z(x,y);
        break;
    end
end
save_dir = fullfile([main_add,'\step2_simulation\data']);
save( [save_dir '\Estimated_Parameter_RWW.mat'],'Para_E','rrr_z_max');