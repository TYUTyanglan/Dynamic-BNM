function [Para_E,FCr_z]=GA_rww(Tepochlong,TR,N_core,dt,main_add)

poolobj = gcp('nocreate');
delete(poolobj);

%% setup directory for lib, data, cluster, save
main_dir = fullfile([main_add,'\step1_estimation']);
data_dir = fullfile(main_dir,'data'); 
save_dir_input = fullfile([main_add,'\step2_simulation\data']);
save_dir = save_dir_input;
cluster_dir = save_dir_input;

%-------------------------------------------------------------------------
%% prepare the empirical data y

%load FC and SC
load(fullfile(data_dir,'FCSC_Desikan68_rww.mat'),'FC_emp','SC'); 

FC = FC_emp;
SC = SC./max(max(SC)).*0.2;

%find out number of brain regions
NumC = length(diag(SC)); 

FC_mask = tril(ones(size(FC,1),size(FC,1)),0);
y = FC(~FC_mask); %use the elements above the maiin diagnal, y becomes a vector {samples x 1} 
n = 1;            %only one FC  
T = length(y);    %samples of FC 
nT = n*T;         %number of data samples
y_out=zeros(nT,1);
%-----------------------------------------------------------

%% begin estimation
% Node natural frequency in Hz 
Nstate = rng;

%setup the cluster
cluster = parcluster('local');
cluster.JobStorageLocation = cluster_dir;
parpool(cluster,N_core);

%--------------------------------------start whole loop, begin estimation

%GA
ObjectiveFunction =  @(P)GA_fitness_rww(P,SC,y,FC_mask,y_out,Nstate,Tepochlong,TR,dt);
nvars = 4;  %Number of variables
LB = [0.1;0.2;1;0.0005];    %Lower limit
UB = [1;0.4;6;0.0015];    %Domain limit
options=gaoptimset();
options.FitnessLimit=0.05;
options.Generations=100;
options.UseParallel='always';
[P,CC_check,reason] = ga(ObjectiveFunction,nvars,[],[],[],[],LB,UB,[],options)    

FCr_z=0.4-CC_check;
Para_E=P;
fix(clock)
save( [save_dir '\Estimated_Parameter_RWW.mat'],'Para_E','FCr_z');

poolobj = gcp('nocreate');
delete(poolobj);
