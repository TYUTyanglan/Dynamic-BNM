function [FCr_z,Metastable,Synchrony,meta1]=estimation_main_kj_noise_filter(f,Tmax,TR,dt,N_core,noise,low_f,high_f,main_add)
%% Define here the Network Spatial and Temporal structure
EstimationStep = 10; % user define

poolobj = gcp('nocreate');
delete(poolobj);

%% setup directory for lib, data, cluster, save
main_dir = fullfile([main_add,'\step1_estimation']);
data_dir = fullfile(main_dir,'data'); 
save_dir_input = fullfile([main_add,'\result\KJ']);
save_dir = save_dir_input;
cluster_dir = save_dir_input;

%--------------------------------------------------------------------------
%%  prepare the empirical data y  ->
% Define the strenght of all existing connections between the N nodes
% as a NxN matrix 
load(fullfile(data_dir,'FCSC_Desikan68.mat'),'FC_emp','SC','D'); 
 % Number of coupled Units
N=size(SC,1); 
 
 % Normalize such that the mean of all non-diagonal elements is 1. 
SC=SC/mean(SC(ones(N)-eye(N)>0));
 
 % Distance between areas
  D=D/1000; % Distance matrix in meters

tmax=Tmax*60;
  %find out number of brain regions
NumC = length(diag(SC)); 
Isubdiag = find(tril(ones(N),-1));
time=size(timeseriedata,2);
for seed=1:N
   Xanalytic = hilbert(demean(timeseriedata(seed,:)));
   Phases(seed,:) = angle(Xanalytic);
end
T=10:time-10;
for t=T
    for ii=1:N
        for jj=1:ii-1
            patt(ii,jj)=cos(adif(Phases(ii,t),Phases(jj,t)));
        end
    end
    pattern(t-9,:)=patt(Isubdiag);
end
npattmax=size(pattern,1);
kk3=1;
for t=1:npattmax-2
    p1=mean(pattern(t:t+2,:));
    for t2=t+1:npattmax-2
        p2=mean(pattern(t2:t2+2,:));
        phfcddata(kk3)=dot(p1,p2)/norm(p1)/norm(p2);
        kk3=kk3+1;
    end
end 
 
 FC_mask = tril(ones(size(FC_emp,1),size(FC_emp,1)),0);%�����ȫ��?����FCһ���ľ���
 y = FC_emp(~FC_mask); %use the elements above the maiin diagnal, y becomes a vector {samples x 1} ����ǰ������г�����?
 n = 1;            %only one FC  
 T = length(y);    %samples of FC 
 nT = n*T;         %number of data samples

%-----------------------------------------------------------
 %% Define here the parameters of the network model to be manipulated        
 
     % Global Coupling strength
           k=1:1:25;   %�޸���ϵ��η��?
           m=length(k);
           
     % Mean Delay in seconds 
           md=0.004:0.001:0.015;  %�޸��ӳٵ��η�Χ
           l=length(md);
   
           Metastable=zeros(m,l);
           Synchrony=zeros(m,l);
           rrr = zeros(m,l);                 %save the goodness of fit
           FCr_z  = zeros(m,l);              %save the correlation between emprical FC and simulated FC, z-transfered
           meta1=zeros(m,l);
           syn1=zeros(m,l);
           ksdist=zeros(m,l); 
           H=zeros(m,l); 
           P=zeros(m,l); 
           %setup the cluster

           cluster = parcluster('local');
           cluster.JobStorageLocation = cluster_dir;
           parpool(cluster,N_core);

  %% Call here the function of the Network Model
for i=1:m
   for j=1:l
       K=k(i);
       MD=md(j);
       y_out=zeros(nT,1);
       metastable_sum=0;
       synchrony_sum=0;   
       meta1_sum=0;
       syn1_sum=0;
       phfcd_sim=0;
       for v=1:1:EstimationStep %%�޸����д���
           
           [Phases_Save, dt_save] = Kuramoto_Delays_Run_noise(SC,D,f,K,MD,tmax,dt,noise);
           [BOLD_X] = CompareNeuroimaging(Phases_Save,dt_save);
           bin=TR/dt_save;
           [BOLD_Y] = rfMRI_simBOLD_downsampling(BOLD_X,bin);
           [BOLD_filted] = TS_bandpass_matrix(BOLD_Y,low_f,high_f,TR);
           time_sim=size(BOLD_filted,2);
           for seed=1:N
               Xanalytic_sim = hilbert(demean(BOLD_filted(seed,:)));
               Phasesdata_sim(seed,:) = angle(Xanalytic_sim);
           end
           T=10:time_sim-10;
           for t=T
               for ii=1:N
                   for jj=1:ii-1
                       patt(ii,jj)=cos(adif(Phasesdata_sim(ii,t),Phasesdata_sim(jj,t)));
                   end
               end
               pattern(t-9,:)=patt(Isubdiag);
           end
           npattmax=size(pattern,1);
           kk3=1;
           for t=1:npattmax-2
               p1=mean(pattern(t:t+2,:));
               for t2=t+1:npattmax-2
                   p2=mean(pattern(t2:t2+2,:));
                   phfcd(kk3)=dot(p1,p2)/norm(p1)/norm(p2);
                   kk3=kk3+1;
               end
           end
           phfcd_sim=phfcd+phfcd_sim;
           [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_filted);
           metastable_sum=metastable_sum+metastable_sim;
           synchrony_sum=synchrony_sum+synchrony_sim;
           FC_sim=corrcoef(BOLD_Y');
           y_out=y_out+FC_sim(~FC_mask);
           syn1_sum=abs(synchrony-synchrony_sim)+syn1_sum;
           meta1_sum=abs(metastable-metastable_sim)+meta1_sum;
       end
       meta1(i,j)=meta1_sum/EstimationStep;
       syn1(i,j)=syn1_sum/EstimationStep;
       y_out_ave=y_out/EstimationStep;
       rrr(i,j) = 1-(var(y-y_out_ave)/var(y));%goodness of fit
       FCr_z(i,j)= corr(atanh(y_out_ave),atanh(y)); %correlation between 2 FCs
       Metastable(i,j)=metastable_sum/EstimationStep;
       Synchrony(i,j)=synchrony_sum/EstimationStep;
       phfcd=phfcd_sim/EstimationStep;
       [H(i,j),P(i,j),ksdist(i,j)]=kstest2(phfcddata,phfcd);
   end
end   
 save( [save_dir '\Estimated_Parameter_K.mat'],'FCr_z','Metastable','Synchrony','meta1','syn1','ksdist');

poolobj = gcp('nocreate');
delete(poolobj);

