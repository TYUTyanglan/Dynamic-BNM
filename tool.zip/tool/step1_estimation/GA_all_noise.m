function [P,FCr_z]=GA_all_noise(f,Tmax,TR,dt,noise,N_core,main_add)

poolobj = gcp('nocreate');
delete(poolobj);

%% setup directory for lib, data, cluster, save
main_dir = fullfile([main_add,'\step1_estimation']);
data_dir = fullfile(main_dir,'data'); 
save_dir_input = fullfile([main_add,'\step2_simulation\data']);
save_dir = save_dir_input;
cluster_dir = save_dir_input;

%--------------------------------------------------------------------------
%% prepare the empirical data y

%load FC and SC
load(fullfile(data_dir,'FCSC_Desikan68.mat'),'FC_emp','SC','D'); 

FC = FC_emp; 
N=size(SC,1); 
SC=SC/mean(SC(ones(N)-eye(N)>0));
D=D/1000;

tmax=Tmax*60;
FC_mask = tril(ones(size(FC,1),size(FC,1)),0);
y = FC(~FC_mask); %use the elements above the maiin diagnal, y becomes a vector {samples x 1} 
n = 1;            %only one FC  
T = length(y);    %samples of FC 
nT = n*T;         %number of data samples
 y_out=zeros(nT,1);

%-----------------------------------------------------------

%% begin estimation
        
%setup the cluster
cluster = parcluster('local');
cluster.JobStorageLocation = cluster_dir;
parpool(cluster,N_core);

%--------------------------------------start whole loop, begin estimation

ObjectiveFunction =  @(P)GA_fitness_noise(P,SC,D,f,y,FC_mask,y_out,tmax,TR,dt,noise);
nvars = 2;  
LB = [4;0.006];    
UB = [15;0.009];    
options=gaoptimset();
options.FitnessLimit=0.05;
options.Generations=50;
options.UseParallel='always';
[P,CC_check,reason] = ga(ObjectiveFunction,nvars,[],[],[],[],LB,UB,[],options)    

FCr_z=0.4-CC_check;

fix(clock)
save( [save_dir '\Estimated_Parameter_K'],'P','FCr_z');

poolobj = gcp('nocreate');
delete(poolobj);
