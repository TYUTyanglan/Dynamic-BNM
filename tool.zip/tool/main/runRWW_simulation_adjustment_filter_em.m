function [metastable,synchrony,FC_emp,Para_E,rrr_z_max]=runRWW_simulation_adjustment_filter_em(SC,tc_emp,Tmax,TR,dt,N_core,low_f,high_f,n,main_add)
FC_emp = corr(tc_emp');
[metastable,synchrony] = BOLD_metastable(tc_emp);
timeseriedata=tc_emp;
save( [main_add,'E:\TVB\tool\step1_estimation\data\FCSC_Desikan68_rww.mat'] ,'FC_emp','SC','timeseriedata');
save([main_add, 'E:\TVB\tool\step2_simulation\data\FCSC_Desikan68_rww.mat'] ,'FC_emp','SC','timeseriedata');
[Para_E,rrr_z_max]=CBIG_MFMem_rfMRI_estimation_main_only4p_filter(Tmax,TR,N_core,low_f,high_f,main_add);
[timeserious,FC_cor]=MFMem_rfMRI_run_10_simulation_filter(Tmax,TR,dt,low_f,high_f,n,main_add);

