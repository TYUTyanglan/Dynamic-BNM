function [FC_sim]=run_simulation_filter(SC,D,P,f,Tmax,TR,dt,TRing,low_f,high_f,n,main_add)
save_dir = fullfile([main_add,'\result\Direct_simulation']); 

N=size(SC,1); 
SC=SC/mean(SC(ones(N)-eye(N)>0));

D=D/1000;

tmax=Tmax*60;

%% begin simulation
for simul=1:1:n
    [Phases_Save, dt_save] = Kuramoto_Delays_Run(SC,D,f,P(1,1),P(1,2),tmax,dt);
    [neuro_act] = CompareNeuroimaging(Phases_Save,dt_save);   
    bin=TRing/dt_save;
    [BOLD_TR] = rfMRI_simBOLD_downsampling(neuro_act,bin);
    [BOLD_TR_filted]=TS_bandpass_matrix(BOLD_TR, low_f, high_f, TRing); 
    FC_sim=corr(BOLD_TR_filted');
    [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR_filted);
    save( [save_dir ,'\',num2str(simul),'_timeserious_k_f.mat'] ,'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
end
end