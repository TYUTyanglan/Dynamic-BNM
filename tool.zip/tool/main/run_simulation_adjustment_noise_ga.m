function [metastable,synchrony,FC_emp,P,FCr_z]=run_simulation_adjustment_noise_ga(SC,D,tc_emp,f,Tmax,TR,dt,noise,N_core,n,main_add)
FC_emp = corr(tc_emp');
[metastable,synchrony] = BOLD_metastable(tc_emp);
timeseriedata=tc_emp;
save([main_add,'\step1_estimation\data\FCSC_Desikan68.mat'] ,'FC_emp','SC','D','timeseriedata');
save([main_add,'\step2_simulation\data\FCSC_Desikan68.mat'] ,'FC_emp','SC','D','timeseriedata');
[P,FCr_z]=GA_all_noise(f,Tmax,TR,dt,noise,N_core,main_add);
[timeserious,FC_cor,FC_sim,metastable_sim,synchrony_sim]=simulations_noise(f,Tmax,TR,dt,noise,n,main_add);