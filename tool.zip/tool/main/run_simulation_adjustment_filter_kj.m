function [metastable,synchrony,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,P,FC_corr,FC_cor]=run_simulation_adjustment_filter_kj(SC,D,tc_emp,f,Tmax,TR,dt,low_f,high_f,N_core,main_add)
FC_emp = corr(tc_emp');
[metastable,synchrony] = BOLD_metastable(tc_emp);
timeseriedata=tc_emp;
save([main_add,'\step1_estimation\data\FCSC_Desikan68.mat'],'FC_emp','SC','D','timeseriedata');
save([main_add,'\step2_simulation\data\FCSC_Desikan68.mat'],'FC_emp','SC','D','timeseriedata');
[FCr_z,Metastable,Synchrony,meta1,syn1,cor_op]=estimation_main_kj_filter(f,Tmax,TR,dt,N_core,low_f,high_f,main_add,synchrony,metastable);
[P,FC_corr]=GS_k(Metastable,metastable,cor_op,FCr_z,main_add);
[timeserious,FC_cor,FC_sim,metastable_sim,synchrony_sim]=simulations_filter(f,Tmax,TR,dt,low_f,high_f,n,main_add);

