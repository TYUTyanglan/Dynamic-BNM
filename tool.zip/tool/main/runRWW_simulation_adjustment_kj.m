function [metastable,synchrony,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,Para_E,rrr_z_max,FC_cor]=runRWW_simulation_adjustment_kj(SC,tc_emp,Tmax,TR,dt,N_core,main_add)
FC_emp = corr(tc_emp');
[metastable,synchrony] = BOLD_metastable(tc_emp);
timeseriedata=tc_emp;
save([main_add,'\step1_estimation\data\FCSC_Desikan68_rww.mat'] ,'FC_emp','SC','timeseriedata');
save([main_add,'\step2_simulation\data\FCSC_Desikan68_rww.mat'] ,'FC_emp','SC','timeseriedata');
[FCr_z,Metastable,Synchrony,meta1,syn1,cor_op]=RWW_KJ(Tmax,TR,dt,N_core,main_add,synchrony,metastable);
[Para_E,rrr_z_max]=GS_rww(Metastable,metastable,cor_op,FCr_z,main_add);
[timeserious,FC_cor]=MFMem_rfMRI_run_10_simulation_kj(Tmax,TR,dt,n,main_add);



