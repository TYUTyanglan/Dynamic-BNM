function [FC_sim]=runRWW_simulation_filter(SC,Para_E,Tmax,TR,dt,TRing,low_f,high_f,n,main_add)
save_dir = fullfile([main_add,'\result\Direct_simulation']); 

SC = SC./max(max(SC)).*0.2;

%% begin simulation
for simul=1:1:n
   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto_timeserice(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TRing/dt); %down sample 
   [BOLD_TR_filted]=TS_bandpass_matrix(BOLD_TR, low_f, high_f, TRing);
   FC_sim = corr(BOLD_TR_filted'); 
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR_filted);
   save( [save_dir ,'/',num2str(simul),'_timeserious_rww_f.mat'] ,'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
end
