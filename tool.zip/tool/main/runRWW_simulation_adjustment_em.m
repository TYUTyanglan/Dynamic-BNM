function [metastable,synchrony,FC_emp,Para_E,rrr_z_max]=runRWW_simulation_adjustment_em(SC,tc_emp,Tmax,TR,dt,N_core,n,main_add)
FC_emp = corr(tc_emp');
[metastable,synchrony] = BOLD_metastable(tc_emp);
timeseriedata=tc_emp;
save( [main_add,'\step1_estimation\data\FCSC_Desikan68_rww.mat'] ,'FC_emp','SC','timeseriedata');
save( [main_add,'\step2_simulation\data\FCSC_Desikan68_rww.mat'],'FC_emp','SC','timeseriedata');
[Para_E,rrr_z_max]=CBIG_MFMem_rfMRI_estimation_main_only4p(Tmax,TR,N_core,main_add);
[timeserious,FC_cor]=MFMem_rfMRI_run_10_simulation(Tmax,TR,dt,n,main_add);

