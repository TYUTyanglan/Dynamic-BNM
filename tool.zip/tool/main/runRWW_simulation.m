function [FC_sim]=runRWW_simulation(SC,Para_E,Tmax,TR,dt,TRing,n,main_add)
save_dir = fullfile([main_add,'\result\Direct_simulation']); 

SC = SC./max(max(SC)).*0.2;

%% begin simulation
for simul=1:1:n
   Nstate = rng;
   [BOLD_act,neuro_act] = MFMem_rfMRI_nsolver_eul_sto_timeserice(Para_E,SC,Nstate,Tmax,dt);
   [BOLD_TR]=rfMRI_simBOLD_downsampling(BOLD_act,TRing/dt); %down sample 
   FC_sim = corr(BOLD_TR'); 
   [metastable_sim,synchrony_sim] = BOLD_metastable(BOLD_TR);
   save( [save_dir ,'/',num2str(simul),'_timeserious_rww.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
end