function varargout = tool(varargin)
% TOOL MATLAB code for tool.fig
%      TOOL, by itself, creates a new TOOL or raises the existing
%      singleton*.
%
%      H = TOOL returns the handle to a new TOOL or the handle to
%      the existing singleton*.
%
%      TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TOOL.M with the given input arguments.
%
%      TOOL('Property','Value',...) creates a new TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tool

% Last Modified by GUIDE v2.5 16-Jul-2021 15:09:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tool_OpeningFcn, ...
                   'gui_OutputFcn',  @tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tool is made visible.
function tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tool (see VARARGIN)

% Choose default command line output for tool
handles.output = hObject;
axes(handles.axes1)
cite=imread('kk.png');
imshow(cite);

% Update handles structure
guidata(hObject, handles);

set(handles.checkbox3,'enable','off');
set(handles.checkbox4,'enable','off');
set(handles.checkbox7,'enable','off');
set(handles.radiobutton1,'enable','off');
set(handles.radiobutton2,'enable','off');
set(handles.radiobutton3,'enable','off');
set(handles.edit2,'enable','off');
set(handles.edit3,'enable','off');
set(handles.edit4,'enable','off');
set(handles.edit5,'enable','off');
set(handles.edit6,'enable','off');
set(handles.edit7,'enable','off');
set(handles.edit8,'enable','off');
set(handles.edit9,'enable','off');
set(handles.edit10,'enable','off');
set(handles.edit11,'enable','off');
set(handles.pushbutton5,'enable','off');
set(handles.pushbutton6,'visible','off');
set(handles.pushbutton7,'visible','off');
set(handles.pushbutton8,'visible','off');
set(handles.pushbutton9,'visible','off');
set(handles.pushbutton10,'visible','off');
set(handles.pushbutton11,'visible','off');
set(handles.pushbutton12,'visible','off');

% UIWAIT makes tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
set(handles.checkbox3,'enable','on');
set(handles.checkbox4,'enable','on');

% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
set(handles.checkbox3,'enable','on');
set(handles.checkbox4,'enable','on');

% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3
var=get(handles.checkbox1,'value');
var1=get(handles.checkbox2,'value');
if var==1
    set(handles.checkbox7,'enable','on');
    set(handles.edit2,'enable','on');
    set(handles.edit3,'enable','on');
    set(handles.edit4,'enable','on');
    set(handles.edit5,'enable','on');
    set(handles.edit6,'enable','on');
    set(handles.edit7,'enable','on');
    set(handles.edit10,'enable','on');
    set(handles.pushbutton5,'enable','on');
else
    if var1==1
        set(handles.checkbox7,'enable','on');
        set(handles.edit2,'enable','on');
        set(handles.edit3,'enable','on');
        set(handles.edit4,'enable','on');
        set(handles.edit7,'enable','on');
        set(handles.edit10,'enable','on');
        set(handles.pushbutton6,'visible','on');
    end
end

% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4
set(handles.radiobutton1,'enable','on');
set(handles.radiobutton2,'enable','on');
set(handles.radiobutton3,'enable','on');

% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
var=get(handles.checkbox1,'value');
var1=get(handles.checkbox2,'value');
if var==1
    set(handles.checkbox7,'enable','on');
    set(handles.edit2,'enable','on');
    set(handles.edit3,'enable','on');
    set(handles.edit4,'enable','on');
    set(handles.edit5,'enable','on');
    set(handles.edit6,'enable','on');
    set(handles.edit10,'enable','on');
    set(handles.edit11,'enable','on');
    set(handles.pushbutton7,'visible','on');
else
    if var1==1
        set(handles.checkbox7,'enable','on');
        set(handles.edit2,'enable','on');
        set(handles.edit3,'enable','on');
        set(handles.edit4,'enable','on');
        set(handles.edit10,'enable','on');
        set(handles.edit11,'enable','on');
        set(handles.pushbutton10,'visible','on');
    end
end

% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
var=get(handles.checkbox1,'value');
var1=get(handles.checkbox2,'value');
if var==1
    set(handles.checkbox7,'enable','on');
    set(handles.edit2,'enable','on');
    set(handles.edit3,'enable','on');
    set(handles.edit4,'enable','on');
    set(handles.edit5,'enable','on');
    set(handles.edit6,'enable','on');
    set(handles.edit10,'enable','on');
    set(handles.edit11,'enable','on');
    set(handles.pushbutton8,'visible','on');
else
    if var1==1
        set(handles.checkbox7,'enable','on');
        set(handles.edit2,'enable','on');
        set(handles.edit3,'enable','on');
        set(handles.edit4,'enable','on');
        set(handles.edit10,'enable','on');
        set(handles.edit11,'enable','on');
        set(handles.pushbutton11,'visible','on');
    end
end

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
var=get(handles.checkbox1,'value');
var1=get(handles.checkbox2,'value');
if var==1
    set(handles.checkbox7,'enable','on');
    set(handles.edit2,'enable','on');
    set(handles.edit3,'enable','on');
    set(handles.edit4,'enable','on');
    set(handles.edit5,'enable','on');
    set(handles.edit6,'enable','on');
    set(handles.edit11,'enable','on');
    set(handles.pushbutton9,'visible','on');
else
    if var1==1
        set(handles.checkbox7,'enable','on');
        set(handles.edit2,'enable','on');
        set(handles.edit3,'enable','on');
        set(handles.edit4,'enable','on');
        set(handles.edit11,'enable','on');
        set(handles.pushbutton12,'visible','on');
    end
end

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pathname=uigetdir('.','...');
str=pathname;
set(handles.edit1,'String',str);
subdirr  = dir( str );

for i = 1 : length( subdirr )
    if( isequal( subdirr( i ).name, '.' )||...
        isequal( subdirr( i ).name, '..')||...
        ~subdirr( i ).isdir)   % �������Ŀ¼������
        continue;
    end 
    out{i-2}=subdirr(i).name;
    disp(out)  
end
set(handles.listbox1,'String',out);

% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7
varr=get(handles.checkbox7,'value');
if varr==1
    set(handles.edit8,'enable','on');
    set(handles.edit9,'enable','on');
else
    if varr==0
        set(handles.edit8,'enable','off');
        set(handles.edit9,'enable','off');
    end
end


function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, ~, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.checkbox1,'value',0);
set(handles.checkbox2,'value',0);
set(handles.checkbox3,'value',0);
set(handles.checkbox4,'value',0);
set(handles.radiobutton1,'value',0);
set(handles.radiobutton2,'value',0);
set(handles.radiobutton3,'value',0);
set(handles.listbox1,'string','');
set(handles.edit1,'String','');
set(handles.edit2,'String','');
set(handles.edit3,'String',1e-3);
set(handles.edit4,'String','');
set(handles.edit5,'String',0);
set(handles.edit6,'String',40);
set(handles.edit7,'String','');
set(handles.checkbox7,'value',0);
set(handles.edit8,'String',0.04);
set(handles.edit9,'String',0.07);
set(handles.edit10,'String',2);
set(handles.edit11,'String',2);
set(handles.checkbox3,'enable','off');
set(handles.checkbox4,'enable','off');
set(handles.checkbox7,'enable','off');
set(handles.radiobutton1,'enable','off');
set(handles.radiobutton2,'enable','off');
set(handles.radiobutton3,'enable','off');
set(handles.edit2,'enable','off');
set(handles.edit3,'enable','off');
set(handles.edit4,'enable','off');
set(handles.edit5,'enable','off');
set(handles.edit6,'enable','off');
set(handles.edit7,'enable','off');
set(handles.edit8,'enable','off');
set(handles.edit9,'enable','off');
set(handles.edit10,'enable','off');
set(handles.edit11,'enable','off');
set(handles.pushbutton5,'enable','off');
set(handles.pushbutton6,'visible','off');
set(handles.pushbutton7,'visible','off');
set(handles.pushbutton8,'visible','off');
set(handles.pushbutton9,'visible','off');
set(handles.pushbutton10,'visible','off');
set(handles.pushbutton11,'visible','off');
set(handles.pushbutton12,'visible','off');

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 [filename, pathname] = uiputfile({'*.mat'}, 'Save Parameters As');
 if ischar(filename)
     Kuramoto= get(handles.checkbox1,'value');
     Reduced_Wongwang= get(handles.checkbox2,'value');
     Direct_simulation = get(handles.checkbox3,'value');
     Adjustment_simulation = get(handles.checkbox4,'value');
     GA=get(handles.radiobutton1,'value');
     EM=get(handles.radiobutton2,'value');
     para_space=get(handles.radiobutton3,'value');
     File_address=get(handles.edit1,'String');
     Times=get(handles.edit2,'String');
     Integration_step=get(handles.edit3,'String');
     TR=get(handles.edit4,'String');
     noise=get(handles.edit5,'String');
     f=get(handles.edit6,'String');
     Downsampling=get(handles.edit7,'String');
     Bandpass_filtering=get(handles.checkbox7,'value');
     low_f=get(handles.edit8,'String');
     high_f=get(handles.edit9,'String');
     Num_Simulation=get(handles.edit10,'String');
     Num_Parallel=get(handles.edit11,'String');
     save(['',pathname,filename,''], 'Kuramoto','Reduced_Wongwang','Direct_simulation','Adjustment_simulation','GA','EM','para_space','File_address','Times','Integration_step','TR','noise','f','Downsampling','Bandpass_filtering','low_f','high_f','Num_Simulation','Num_Parallel');
 end

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open('simulation_help.pdf');

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton5 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton5 ,'ForegroundColor');
set(handles.pushbutton5 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    
    subdirpath1 = fullfile( maindir, subdir( i ).name, 'D.mat' );
    D = load( subdirpath1 );
    D=cell2mat(struct2cell(D));
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));
    
    subdirpath3 = fullfile( maindir, subdir( i ).name, 'P.mat' );
    P = load( subdirpath3,'P');
    P=cell2mat(struct2cell(P));
    
    ff=get(handles.edit6,'String');
    f=str2double(ff);

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);

    tring=get(handles.edit7,'String');
    TRing=str2double(tring);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
    
    no=get(handles.edit5,'String');
    noise=str2double(no);
    disp(noise)
    
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(noise==0&&varr==0)
        [FC]=run_simulation(SC,D,P,f,Tmax,TR,dt,TRing,n,main_add);
        for ii=1:n
            load ([main_add,'\result\Direct_simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end
            save( [ss,'\result\',num2str(ii),'_timeserious_k_S.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
        end
    else
        if(noise~=0&&varr==0)
            [FC]=run_simulation(SC,D,P,f,Tmax,TR,dt,TRing,noise,n,main_add)
            for ii=1:n
                load ([main_add,'\result\Direct_simulation\',num2str(ii),'_timeserious_k_n.mat'],'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end
                save( [ss,'\result\',num2str(ii),'_timeserious_k_S_n.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
            end
        end
        if(noise==0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [FC]=run_simulation_filter(SC,D,P,f,Tmax,TR,dt,TRing,low_f,high_f,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Direct_simulation\',num2str(ii),'_timeserious_k_f.mat'],'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result\',num2str(ii),'_timeserious_k_S_f.mat'] ,'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
            end
        end
        if(noise~=0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [FC]=run_simulation_noise_filter(SC,D,P,f,Tmax,TR,dt,TRing,noise,low_f,high_f,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Direct_simulation\',num2str(ii),'_timeserious_k_nf.mat'],'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end
                save( [ss,'\result\',num2str(ii),'_timeserious_k_S_nf.mat'] ,'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
            end
        end
    end
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str)
    set(handles.pushbutton5 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end

	
% UpdateDisplay(handles); 


function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton6 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton6 ,'ForegroundColor');
set(handles.pushbutton6 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));
    
    subdirpath3 = fullfile( maindir, subdir( i ).name, 'Para_E.mat' );
    para_E = load( subdirpath3,'Para_E' );
    Para_E=cell2mat(struct2cell(para_E));
    
    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);

    tring=get(handles.edit7,'String');
    TRing=str2double(tring);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
     
   varr=get(handles.checkbox7,'value');
   disp(varr)
    
   if(varr==0)
       [FC]=runRWW_simulation(SC,Para_E,Tmax,TR,dt,TRing,n,main_add);
       for ii=1:n
           load ([main_add,'\result\Direct_simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
           ss=fullfile( maindir,subdir( i ).name);
           new_folder = sprintf('%s/%s', ss, 'result'); 
           if exist(new_folder)==0
               mkdir(new_folder); 
           end 
           save( [ss,'\result\',num2str(ii),'_timeserious_rww_S.mat'] ,'BOLD_TR','metastable_sim','synchrony_sim','FC_sim');
       end
   else
       if(varr==1)
           low=get(handles.edit8,'String');
           low_f=str2double(low);
           high=get(handles.edit9,'String');
           high_f=str2double(high);
           [FC]=runRWW_simulation_filter(SC,Para_E,Tmax,TR,dt,TRing,low_f,high_f,n,main_add);
           for ii=1:n
               load ([main_add,'\result\Direct_simulation\',num2str(ii),'_timeserious_rww_f.mat'],'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
               ss=fullfile( maindir,subdir( i ).name);
               new_folder = sprintf('%s/%s', ss, 'result'); 
               if exist(new_folder)==0
                   mkdir(new_folder); 
               end 
               save( [ss,'\result\',num2str(ii),'_timeserious_rww_S_f.mat'] ,'BOLD_TR_filted','metastable_sim','synchrony_sim','FC_sim');
           end
       end
   end
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str)   
    set(handles.pushbutton6 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton7 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton7 ,'ForegroundColor');
set(handles.pushbutton7 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    subdirpath = fullfile( maindir, subdir( i ).name, '*.dat' );
    dat = dir( subdirpath );               % ���ļ������Һ�׺Ϊdat���ļ�

    for j = 1 : length( dat )
        datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
        tc_emp = (load( datpath ))';
    end
    
    subdirpath1 = fullfile( maindir, subdir( i ).name, 'D.mat' );
    D = load( subdirpath1 );
    D=cell2mat(struct2cell(D));
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));
    
    ff=get(handles.edit6,'String');
    f=str2double(ff);

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);
    
    ncore=get(handles.edit11,'String');
    N_core=str2double(ncore);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
    
    no=get(handles.edit5,'String');
    noise=str2double(no);
    
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(noise==0&&varr==0)
        [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_ga(SC,D,tc_emp,f,Tmax,TR,dt,N_core,n,main_add);
        for ii=1:n
            load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result_ga'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end  
            save( [ss,'\result_ga\',num2str(ii),'_timeserious_k_A_Ga.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
        end
        save([ss,'\result_ga\P.mat'],'P','FCr_z');
        save([ss,'\result_ga\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
    else
        if(noise~=0&&varr==0)
            [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_noise_ga(SC,D,tc_emp,f,Tmax,TR,dt,noise,N_core,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_ga'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end  
                save( [ss,'\result_ga\',num2str(ii),'_timeserious_k_A_Ga_n.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_ga\P.mat'],'P','FCr_z');
            save([ss,'\result_ga\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
        if(noise==0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_filter_ga(SC,D,tc_emp,f,Tmax,TR,dt,low_f,high_f,N_core,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_ga'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_ga\',num2str(ii),'_timeserious_k_A_Ga_f.mat'] ,'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_ga\P.mat'],'P','FCr_z');
            save([ss,'\result_ga\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
        if(noise~=0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_noise_filter_ga(SC,D,tc_emp,f,Tmax,TR,dt,noise,low_f,high_f,N_core,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_ga'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_ga\',num2str(ii),'_timeserious_k_A_Ga_nf.mat'] ,'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_ga\P.mat'],'P','FCr_z');
            save([ss,'\result_ga\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
    end
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str)
    set(handles.pushbutton7 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton8 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton8 ,'ForegroundColor');
set(handles.pushbutton8 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    subdirpath = fullfile( maindir, subdir( i ).name, '*.dat' );
    dat = dir( subdirpath );               % ���ļ������Һ�׺Ϊdat���ļ�

    for j = 1 : length( dat )
        datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
        tc_emp = (load( datpath ))';
    end
    
    subdirpath1 = fullfile( maindir, subdir( i ).name, 'D.mat' );
    D = load( subdirpath1 );
    D=cell2mat(struct2cell(D));
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));
    
    ff=get(handles.edit6,'String');
    f=str2double(ff);

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);
    
    ncore=get(handles.edit11,'String');
    N_core=str2double(ncore);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
    
    no=get(handles.edit5,'String');
    noise=str2double(no);
    
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(noise==0&&varr==0)
        [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_em(SC,D,tc_emp,f,Tmax,TR,dt,N_core,n,main_add);
        for ii=1:n
            load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result_em'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end
            save( [ss,'\result_em\',num2str(ii),'_timeserious_k_A_Em.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
        end
        save([ss,'\result_em\P.mat'],'P','FCr_z');
        save([ss,'\result_em\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
    else
        if(noise~=0&&varr==0)
            [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_em_noise(SC,D,tc_emp,f,Tmax,TR,dt,noise,N_core,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_em'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_em\',num2str(ii),'_timeserious_k_A_Em_n.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_em\P.mat'],'P','FCr_z');
            save([ss,'\result_em\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
        if(noise==0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_em_filter(SC,D,tc_emp,f,Tmax,TR,dt,low_f,high_f,N_core,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_em'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\reesult_em\',num2str(ii),'_timeserious_k_A_Em_f.mat'] ,'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_em\P.mat'],'P','FCr_z');
            save([ss,'\result_em\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
        if(noise~=0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,P,FCr_z]=run_simulation_adjustment_em_noise_filter(SC,D,tc_emp,f,Tmax,TR,dt,noise,low_f,high_f,N_core,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_em'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_em\',num2str(ii),'_timeserious_k_A_Em_nf.mat'] ,'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_em\P.mat'],'P','FCr_z');
            save([ss,'\result_em\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
    end  
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str)    
    set(handles.pushbutton8 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton9 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton9 ,'ForegroundColor');
set(handles.pushbutton9 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    subdirpath = fullfile( maindir, subdir( i ).name, '*.dat' );
    dat = dir( subdirpath );               % ���ļ������Һ�׺Ϊdat���ļ�

    for j = 1 : length( dat )
        datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
        tc_emp = (load( datpath ))';
    end
    
    subdirpath1 = fullfile( maindir, subdir( i ).name, 'D.mat' );
    D = load( subdirpath1 );
    D=cell2mat(struct2cell(D));
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));
    
    ff=get(handles.edit6,'String');
    f=str2double(ff);

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);
    
    ncore=get(handles.edit11,'String');
    N_core=str2double(ncore);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
    
    no=get(handles.edit5,'String');
    noise=str2double(no);
    
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(noise==0&&varr==0)
        [metastable_emp,synchrony_emp,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,P,FC_corr,FC_cor]=run_simulation_adjustment_kj(SC,D,tc_emp,f,Tmax,TR,dt,N_core,main_add,n);
        for ii=1:n
            load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result_kj'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end 
            save( [ss,'\result_kj\',num2str(ii),'_timeserious_k_A_Kj.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
        end
        save([ss,'\result_kj\P.mat'],'P','FC_corr');
        save( [ss,'\result_kj\Parameter_Space_k.mat'] ,'FCr_z','Metastable','Synchrony','meta1','syn1','cor_op');
        save([ss,'\result_kj\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
    else
        if(noise~=0&&varr==0)
            [metastable_emp,synchrony_emp,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,P,FC_corr,FC_cor]=run_simulation_adjustment_noise_kj(SC,D,tc_emp,f,Tmax,TR,dt,noise,N_core,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_kj'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_kj\',num2str(ii),'_timeserious_k_A_Kj_n.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_kj\P.mat'],'P','FC_corr');
            save( [ss,'\result_kj\Parameter_Space_k_n.mat'] ,'FCr_z','Metastable','Synchrony','meta1','syn1','cor_op');
            save([ss,'\result_kj\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
        if(noise==0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,P,FC_corr,FC_cor]=run_simulation_adjustment_filter_kj(SC,D,tc_emp,f,Tmax,TR,dt,low_f,high_f,N_core,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_kj'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_kj\',num2str(ii),'_timeserious_k_A_Kj_f.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_kj\P.mat'],'P','FC_corr');
            save( [ss,'\result_kj\Parameter_Space_k_f.mat'] ,'FCr_z','Metastable','Synchrony','meta1','syn1','cor_op');
            save([ss,'\result_kj\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
        if(noise~=0&&varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,P,FC_corr,FC_cor]=run_simulation_adjustment_noise_filter_kj(SC,D,tc_emp,f,Tmax,TR,dt,noise,low_f,high_f,N_core,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_k.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_kj'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_kj\',num2str(ii),'_timeserious_k_A_Kj_nf.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save([ss,'\result_kj\P.mat'],'P','FC_corr');
            save( [ss,'\result_kj\Parameter_Space_k_nf.mat'] ,'FCr_z','Metastable','Synchrony','meta1','syn1','cor_op');
            save([ss,'\result_kj\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
        end
    end
    
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str)
    set(handles.pushbutton9 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
main_add=pwd;
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
RawBackgroundColor=get(handles.pushbutton10 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton10 ,'ForegroundColor');
set(handles.pushbutton10 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    subdirpath = fullfile( maindir, subdir( i ).name, '*.dat' );
    dat = dir( subdirpath );               % ���ļ������Һ�׺Ϊdat���ļ�

    for j = 1 : length( dat )
        datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
        tc_emp = (load( datpath ))';
    end
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);
    
    ncore=get(handles.edit11,'String');
    N_core=str2double(ncore);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
 
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(varr==0)
        [metastable_emp,synchrony_emp,FC_emp,Para_E,FCr_z]=runRWW_simulation_adjustment_ga(SC,tc_emp,Tmax,TR,dt,N_core,n,main_add);
        for ii=1:n
            load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result_ga'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end 
            save( [ss,'\result_ga\',num2str(ii),'_timeserious_rww_A_Ga.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
        end
        save( [ss,'\result_ga\Para_E.mat'] ,'Para_E','FCr_z');
        save([ss,'\result_ga\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
     else
        if(varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,Para_E,FCr_z]=runRWW_simulation_adjustment_filter_ga(SC,tc_emp,Tmax,TR,dt,N_core,low_f,high_f,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_ga'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end
                save( [ss,'\result_ga\',num2str(ii),'_timeserious_rww_A_Ga_f.mat'] ,'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
             end
             save( [ss,'\result_ga\Para_E.mat'] ,'Para_E','FCr_z');
             save([ss,'\result_ga\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
         end
    end
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str)
    set(handles.pushbutton10 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton11 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton11 ,'ForegroundColor');
set(handles.pushbutton11 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    subdirpath = fullfile( maindir, subdir( i ).name, '*.dat' );
    dat = dir( subdirpath );               % ���ļ������Һ�׺Ϊdat���ļ�

    for j = 1 : length( dat )
        datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
        tc_emp = (load( datpath ))';
    end
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);
    
    ncore=get(handles.edit11,'String');
    N_core=str2double(ncore);
    
    nn=get(handles.edit10,'String');
    n=str2double(nn);
 
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(varr==0)
        [metastable_emp,synchrony_emp,FC_emp,Para_E,FCr_z]=runRWW_simulation_adjustment_em(SC,tc_emp,Tmax,TR,dt,N_core,n,main_add);
        for ii=1:n
            load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result_em'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end 
            save( [ss,'\result_em\',num2str(ii),'_timeserious_rww_A_Em.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
        end
        save( [ss,'\result_em\Para_E.mat'] ,'Para_E','FCr_z');
        save([ss,'\result_em\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
     else
        if(varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,Para_E,FCr_z]=runRWW_simulation_adjustment_filter_em(SC,tc_emp,Tmax,TR,dt,N_core,low_f,high_f,n,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_em'); 
                if exist(new_folder)==0
                    mkdir(new_folder); 
                end 
                save( [ss,'\result_em\',num2str(ii),'_timeserious_rww_A_Em_f.mat'] ,'BOLD_TR_filted','FC_cor','metastable_sim','synchrony_sim','FC_sim');
             end
             save( [ss,'\result_em\Para_E.mat'] ,'Para_E','FCr_z');
             save([ss,'\result_em\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
         end
    end
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str) 
    set(handles.pushbutton11 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_add=pwd;
RawBackgroundColor=get(handles.pushbutton12 ,'BackgroundColor');
RawForegroundColor=get(handles.pushbutton12 ,'ForegroundColor');
set(handles.pushbutton12 ,'Enable', 'off','BackgroundColor', 'red','ForegroundColor','green');

h=waitbar(0,'Please Wait...');
maindir = get(handles.edit1,'String');
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)               % �������Ŀ¼������
        continue;
    end
    subdirpath = fullfile( maindir, subdir( i ).name, '*.dat' );
    dat = dir( subdirpath );               % ���ļ������Һ�׺Ϊdat���ļ�

    for j = 1 : length( dat )
        datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
        tc_emp = (load( datpath ))';
    end
    
    subdirpath2 = fullfile( maindir, subdir( i ).name, 'SC.mat' );
    SC = load( subdirpath2 );
    SC=cell2mat(struct2cell(SC));
    SC=SC-diag(diag(SC));

    ss=get(handles.edit2,'String');
    Tmax=str2double(ss);

    trr=get(handles.edit4,'String');
    TR=str2double(trr);

    dtt=get(handles.edit3,'String');
    dt=str2double(dtt);
    
    ncore=get(handles.edit11,'String');
    N_core=str2double(ncore);
 
    varr=get(handles.checkbox7,'value');
    disp(varr)
    if(varr==0)
        [metastable_emp,synchrony_emp,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,Para_E,rrr_z_max,FC_cor]=runRWW_simulation_adjustment_kj(SC,tc_emp,Tmax,TR,dt,N_core,main_add);
        for ii=1:n
            load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            ss=fullfile( maindir,subdir( i ).name);
            new_folder = sprintf('%s/%s', ss, 'result_kj'); 
            if exist(new_folder)==0
                mkdir(new_folder); 
            end 
            save( [ss,'\result_kj\',num2str(ii),'_timeserious_rww_A_kj.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
        end
        save( [ss,'\result_kj\Para_E.mat'] ,'Para_E','rrr_z_max');
        save( [ss,'\result_kj\Parameter_Space_rww.mat'] ,'FCr_z','Metastable','Synchrony','meta1','syn1','cor_op');
        save([ss,'\result_kj\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
     else
        if(varr==1)
            low=get(handles.edit8,'String');
            low_f=str2double(low);
            high=get(handles.edit9,'String');
            high_f=str2double(high);
            [metastable_emp,synchrony_emp,FC_emp,FCr_z,Metastable,Synchrony,meta1,syn1,cor_op,Para_E,rrr_z_max,FC_cor]=runRWW_simulation_adjustment_filter_kj(SC,tc_emp,Tmax,TR,dt,N_core,low_f,high_f,main_add);
            for ii=1:n
                load ([main_add,'\result\Assistant_Simulation\',num2str(ii),'_timeserious_rww.mat'],'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
                ss=fullfile( maindir,subdir( i ).name);
                new_folder = sprintf('%s/%s', ss, 'result_kj'); 
                if exist(new_folder)==0
                mkdir(new_folder); 
                end 
                save( [ss,'\result_kj\',num2str(ii),'_timeserious_rww_A_kj_f.mat'] ,'BOLD_TR','FC_cor','metastable_sim','synchrony_sim','FC_sim');
            end
            save( [ss,'\result_kj\Para_E.mat'] ,'Para_E','rrr_z_max');
            save( [ss,'\result_kj\Parameter_Space_rww_f.mat'] ,'FCr_z','Metastable','Synchrony','meta1','syn1','cor_op');
            save([ss,'\result_kj\emp.mat'],'metastable_emp','synchrony_emp','FC_emp');
         end
    end
    
    str=['Completed',num2str(i/length( subdir )*100),'%'];
    waitbar(i/length( subdir ),h,str) 
    set(handles.pushbutton12 ,'Enable', 'on','BackgroundColor', RawBackgroundColor,'ForegroundColor',RawForegroundColor); 
end
